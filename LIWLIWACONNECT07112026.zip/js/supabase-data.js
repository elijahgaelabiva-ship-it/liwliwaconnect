// Liwliwa Connect — AppData
// One place that decides where listing data comes from.
//
// While SUPABASE_URL / SUPABASE_ANON_KEY below are empty, everything keeps
// using the old Google Apps Script, so the site never breaks mid-migration.
// Paste your two values in and every page switches to Supabase at once.
// (The anon key is meant to be public — Row Level Security protects the data.
//  NEVER paste the service_role key here.)
window.AppData = (() => {
  const SUPABASE_URL = 'https://dfqilrvhbaxphbsqtpiu.supabase.co';
  const SUPABASE_ANON_KEY = 'sb_publishable_IBAz7hwO-ZR1RrROs-IWYQ_Pva5QTw0'; // publishable key: safe to be public

  const APPS_SCRIPT = 'https://script.google.com/macros/s/AKfycbx1doFh9X93nSzMbxtDFmOUWEDf8MoT7Csb8XiEmKnh7Zw33RDEDjN8N7WlSFTMS5gb/exec';
  const CATEGORIES = ['resorts', 'restaurants', 'cafes', 'surfschools', 'activities'];
  const FIELDS = 'id,category,name,description,photo_url,price_tier,price_range,max_pax,cuisine,amenities,' +
    'contact_number,facebook_url,website_url,instagram_url,latitude,longitude,google_rating,' +
    'google_reviews_count,google_maps_url,featured';

  const enabled = !!(SUPABASE_URL && SUPABASE_ANON_KEY);

  // Returns a normal fetch() Response whose .json() is an array of listings —
  // same shape the pages already expect. type = a category key, or 'all'.
  function fetchListings(type) {
    if (!enabled) return fetch(`${APPS_SCRIPT}?type=${encodeURIComponent(type)}`);
    let url = `${SUPABASE_URL}/rest/v1/listings?select=${FIELDS}&status=eq.approved&order=name.asc`;
    if (type !== 'all') {
      if (!CATEGORIES.includes(type)) return Promise.reject(new Error('Unknown category: ' + type));
      url += `&category=eq.${type}`;
    }
    // New-style publishable keys (sb_publishable_...) are not JWTs: send them as `apikey` only.
    // Legacy anon keys are JWTs (start with 'eyJ') and also go in Authorization.
    const headers = { apikey: SUPABASE_ANON_KEY };
    if (SUPABASE_ANON_KEY.startsWith('eyJ')) headers.Authorization = `Bearer ${SUPABASE_ANON_KEY}`;
    return fetch(url, { headers });
  }

  return { enabled, fetchListings };
})();
