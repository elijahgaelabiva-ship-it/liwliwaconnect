// Liwliwa Connect — Service Worker
//
// WHAT THIS DOES
// - Lets the site be "installed" and opened without internet (offline mode).
// - Caches the app shell (pages, CSS, JS, icons) so repeat visits are instant.
// - Never caches the Google Apps Script API — that's live business data and
//   must always come from the network, never a stale copy.
//
// HOW TO UPDATE THE CACHE AFTER EDITING A FILE
// Every time you change css/style.css, js/main.js, or any .html file and
// redeploy, bump CACHE_VERSION below (v1 -> v2 -> v3 ...). That's the only
// step needed — this file auto-deletes the old cache and re-downloads
// everything fresh the next time someone opens the site. If you forget to
// bump it, people may keep seeing the old version until the cache expires
// on its own.

const CACHE_VERSION = 'v15'; // bumped: Supabase data layer (js/supabase-data.js) + UI V3
const CACHE_NAME = `liwliwa-connect-${CACHE_VERSION}`;

// The "app shell" — everything needed for the site to load and look right
// with zero internet connection. Keep this list in sync with the files in
// the project (README lists them all).
const PRECACHE_URLS = [
  './',
  'index.html',
  'guest-home.html',
  'resorts.html',
  'restaurants.html',
  'cafes.html',
  'surf-schools.html',
  'activities.html',
  'business.html',
  'map.html',
  'register.html',
  'admin.html',
  'dashboard.html',
  'for-business-owners.html',
  'nearby-essentials.html',
  'food-finder.html',
  'parking-guide.html',
  'emergency-help.html',
  'beach-etiquette.html',
  'getting-here.html',
  '404.html',
  '500.html',
  'offline.html',
  'css/style.css',
  'js/main.js',
  'js/supabase-data.js',
  'images/hero-beach.webp',
  'manifest.json',
  'icons/icon-192.png',
  'icons/icon-512.png'
];

// Never touch the live backend (Google Apps Script) with the cache — listing
// data, login, registration, and admin actions must always be real-time.
const NEVER_CACHE_HOSTS = ['script.google.com', 'script.googleusercontent.com', 'supabase.co'];

// ---------- INSTALL ----------
// Downloads and caches the app shell as soon as the new service worker is
// found. skipWaiting() means an update takes over immediately instead of
// waiting for every open tab to be closed first.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => Promise.all(PRECACHE_URLS.map((u) => cache.add(u).catch(() => null))))
      .then(() => self.skipWaiting())
  );
});

// ---------- ACTIVATE ----------
// Deletes any caches left over from a previous CACHE_VERSION, then takes
// control of already-open tabs right away.
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names
          .filter((name) => name.startsWith('liwliwa-connect-') && name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      ))
      .then(() => self.clients.claim())
  );
});

// ---------- FETCH ----------
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only ever intercept GET requests. POST/PUT etc. (form submissions,
  // registration, admin approvals) must always go straight to the network.
  if (request.method !== 'GET') return;

  // Let the live backend through untouched — no caching, no offline fallback.
  if (NEVER_CACHE_HOSTS.some((h) => url.hostname === h || url.hostname.endsWith('.' + h))) return;

  // Page navigations (clicking a link, typing a URL, opening the installed
  // app): try the network first so visitors always get the latest page when
  // they have a connection. If the network fails, fall back to the cached
  // copy of that exact page, and if that page was never visited/cached
  // either, fall back to offline.html.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Only cache real pages (status 200). A 404/500 response should
          // never get stored as "the" cached copy of that URL.
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() =>
          caches.match(request).then((cached) => cached || caches.match('offline.html'))
        )
    );
    return;
  }

  // Everything else (CSS, JS, images, fonts, CDN scripts like Tailwind/
  // Lucide/Leaflet): serve the cached copy instantly if we have one, and
  // quietly refresh the cache in the background so the next visit has the
  // newest version. If nothing's cached yet, fetch from the network and
  // cache it for next time.
  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request)
        .then((response) => {
          // Only cache valid, cacheable responses (basic same-origin OK,
          // and opaque no-cors CDN responses are cached as-is).
          if (response && (response.ok || response.type === 'opaque')) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => cached); // offline and not cached — nothing we can do

      return cached || networkFetch;
    })
  );
});
