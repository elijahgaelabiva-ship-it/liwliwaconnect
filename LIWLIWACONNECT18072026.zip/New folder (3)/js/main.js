// Liwliwa Connect — main.js

// ---------------------------------------------------------------------
// AppImage — image optimization for business photos.
//
// Business owners paste raw photo links from postimages.org/imgur into the
// Dashboard (see PROJECT_STATUS.md). Those originals are whatever size/
// format a phone camera produced — often multi-MB JPEGs — and we have no
// server of our own to resize or convert them (static site, no build step).
//
// wsrv.nl (images.weserv.nl) solves this for free with no signup: give it
// any public image URL and it fetches, resizes, and re-encodes it on the
// fly, cached on their CDN. We use it to:
//   1. Convert everything to WebP (smaller than JPEG/PNG at the same quality)
//   2. Serve a size that actually matches where the image is displayed,
//      instead of shipping a full-resolution photo into a 300px card
//   3. Provide a srcset so phones pick the smallest size that still looks
//      sharp on their screen
//
// Pair with loading="lazy" (native lazy loading) so off-screen images don't
// download until the visitor scrolls near them.
// ---------------------------------------------------------------------
window.AppImage = (() => {
  const PROXY = 'https://wsrv.nl/';

  function escAttr(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  // Builds a wsrv.nl URL: fetch `rawUrl`, resize so it's at most `width`px
  // wide (aspect ratio kept, never upscaled), re-encode as WebP.
  function optimizedUrl(rawUrl, width, quality = 75) {
    if (!rawUrl) return '';
    const params = new URLSearchParams({
      url: rawUrl,
      w: String(width),
      output: 'webp',
      q: String(quality),
      fit: 'inside', // resize only, no cropping — CSS object-cover/background-size handles the crop
      we: '1'        // "without enlarge" — never blow up a small source photo
    });
    return `${PROXY}?${params.toString()}`;
  }

  // Ready-to-insert <img> tag for a listing card: WebP, lazy-loaded,
  // responsive srcset, and the original tap-to-retry-broken-image fallback
  // pattern (calls the page's own placeholderPhotoHtml()).
  function cardImg(rawUrl, altText, opts = {}) {
    if (!rawUrl) return '';
    const {
      className = 'w-full h-44 object-cover rounded-t-2xl',
      priority = false,
      // Pages that list placeholderPhotoHtml() (the 5 directory pages) get a
      // nice placeholder box on a broken image. Pages without it (like
      // guest-home's featured cards, which already have a gradient sitting
      // behind the image) just hide the broken <img> instead.
      onError = "this.replaceWith(document.createRange().createContextualFragment(placeholderPhotoHtml()))"
    } = opts;
    const widths = [400, 800, 1200];
    const srcset = widths.map((w) => `${optimizedUrl(rawUrl, w)} ${w}w`).join(', ');
    return `<img src="${optimizedUrl(rawUrl, 800)}" srcset="${srcset}" sizes="(min-width: 1024px) 360px, (min-width: 640px) 46vw, 92vw" alt="${escAttr(altText)}" class="${className}" loading="${priority ? 'eager' : 'lazy'}" decoding="async"${priority ? ' fetchpriority="high"' : ''} onerror="${escAttr(onError)}" />`;
  }

  return { optimizedUrl, cardImg };
})();


// ---------------------------------------------------------------------
// AppAnalytics — client side of the Business Analytics System.
// Backend: Analytics.gs (paste into the Apps Script project alongside
// Code.gs). See docs/API.md "Analytics" section for the full picture.
//
// Every call is fire-and-forget: it never blocks, delays, or can fail the
// action it's attached to (opening the dialer, maps, a website...). That's
// the #1 requirement of this feature — analytics must fail silently.
// ---------------------------------------------------------------------
window.AppAnalytics = (() => {
  const ENDPOINT = 'https://script.google.com/macros/s/AKfycbx1doFh9X93nSzMbxtDFmOUWEDf8MoT7Csb8XiEmKnh7Zw33RDEDjN8N7WlSFTMS5gb/exec';
  const GUEST_ID_KEY = 'liwliwa_guest_id';

  // A stable anonymous id for this browser, so repeat visits from the same
  // guest can be told apart from separate guests. There's no guest login
  // system in the app yet, so this is always the "not logged in" case the
  // Analytics sheet allows (GuestID column blank) — except we still fill
  // it in with an anonymous id, which is more useful for counting unique
  // visitors than leaving it blank. Swap this out if/when real guest
  // accounts exist.
  function getGuestId() {
    try {
      let id = localStorage.getItem(GUEST_ID_KEY);
      if (!id) {
        id = 'guest_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        localStorage.setItem(GUEST_ID_KEY, id);
      }
      return id;
    } catch (e) {
      return ''; // private browsing / storage blocked — tracking still works, just anonymous
    }
  }

  // Apps Script web apps never receive the request's User-Agent header, so
  // device type can't be detected on the server. It's detected once, here,
  // in the browser instead — still fully automatic, no guest input needed,
  // just computed in a different place than a typical server would.
  function detectDevice() {
    const ua = navigator.userAgent || '';
    const touchPoints = navigator.maxTouchPoints || 0;
    const minDim = Math.min(window.innerWidth || 0, window.innerHeight || 0);

    const isTablet = /iPad|Tablet/i.test(ua) ||
      (/Android/i.test(ua) && !/Mobile/i.test(ua)) ||
      (touchPoints > 1 && minDim >= 600);
    if (isTablet) return 'Tablet';

    const isMobile = /Mobi|Android|iPhone|iPod/i.test(ua) || (window.innerWidth || 9999) < 768;
    return isMobile ? 'Mobile' : 'Desktop';
  }

  // Logs one event. Uses sendBeacon when available — unlike a normal
  // fetch(), it's guaranteed to actually complete even if the page
  // navigates away (e.g. tapping "Website" immediately unloads the page).
  function track(businessId, eventType, notes) {
    if (!businessId || !eventType) return; // e.g. id not wired up on this page yet — no-op, not an error
    try {
      const payload = JSON.stringify({
        action: 'log_analytics',
        businessId,
        eventType,
        guestId: getGuestId(),
        device: detectDevice(),
        notes: notes || '-'
      });

      // THE BUG: navigator.sendBeacon() to a Google Apps Script /exec URL
      // is known to silently fail to deliver in many real-world browsers —
      // Apps Script's response handling doesn't play well with the Beacon
      // API's strict rules, so the click fires but the row never gets
      // written, with nothing anywhere to surface that failure. fetch()
      // with keepalive:true still survives a page unload and is the exact
      // same pattern every other working request in this app already uses.
      fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: payload,
        keepalive: true
      }).catch(() => {});
    } catch (e) {
      // Never let a tracking failure surface to the caller — see file header.
    }
  }

  return { track, detectDevice, getGuestId };
})();

// ---------------------------------------------------------------------
// AppChart — minimal bar chart, pure HTML/CSS (no chart library, per
// project's "no heavy libraries" rule). Used by the Analytics sections in
// dashboard.html and admin.html.
// ---------------------------------------------------------------------
window.AppChart = {
  // data: [{ label, value }]. Renders into `container` (a DOM element).
  bar(container, data, opts = {}) {
    if (!container) return;
    if (!data || data.length === 0) {
      container.innerHTML = '<p class="text-xs text-ink/40 py-8 text-center">No data yet for this range.</p>';
      return;
    }
    const { color = '#17A398', heightPx = 110 } = opts;
    const max = Math.max(...data.map((d) => d.value), 1);
    const esc = (v) => { const d = document.createElement('div'); d.textContent = String(v ?? ''); return d.innerHTML; };

    container.innerHTML = `
      <div class="flex items-end gap-1.5" style="height:${heightPx}px;">
        ${data.map((d) => `
          <div class="flex-1 min-w-0 flex flex-col items-center justify-end h-full" title="${esc(d.label)}: ${esc(d.value)}">
            <span class="text-[10px] text-ink/50 mb-1">${esc(d.value)}</span>
            <div style="height:${Math.max((d.value / max) * 78, 3)}%; background:${color};" class="w-full rounded-t-md"></div>
            <span class="text-[9px] text-ink/40 mt-1 truncate w-full text-center">${esc(d.label)}</span>
          </div>
        `).join('')}
      </div>`;
  }
};

// ---------------------------------------------------------------------
// Shared analytics summary-card definitions + renderer, used by both
// dashboard.html (one business's numbers) and admin.html (sitewide) so
// this list exists in exactly one place.
// ---------------------------------------------------------------------
window.ANALYTICS_CARD_DEFS = [
  { key: 'VIEW', label: 'Profile Views', emoji: '👁' },
  { key: 'CALL', label: 'Call Clicks', emoji: '📞' },
  { key: 'DIRECTION', label: 'Direction Clicks', emoji: '📍' },
  { key: 'WEBSITE', label: 'Website Clicks', emoji: '🌐' },
  { key: 'FACEBOOK', label: 'Facebook Clicks', emoji: '📘' },
  { key: 'INSTAGRAM', label: 'Instagram Clicks', emoji: '📷' },
  { key: 'SHARE', label: 'Shares', emoji: '🔗' },
  { key: 'PHOTO_VIEW', label: 'Photo Views', emoji: '🖼️' },
  { key: 'EVENT_CLICK', label: 'Event Clicks', emoji: '🎟️' },
  { key: 'FAVORITE', label: 'Favorites', emoji: '❤️' }
];

window.AppAnalyticsCards = {
  // Renders the 10 summary cards from a `counts` object — as returned by
  // Analytics.gs's getBusinessAnalytics()/getAnalyticsSummary() — into `container`.
  render(container, counts) {
    if (!container) return;
    counts = counts || {};
    container.innerHTML = window.ANALYTICS_CARD_DEFS.map((def) => `
      <div class="bg-sand/60 rounded-xl px-3 py-2.5 flex flex-col gap-0.5">
        <span class="text-lg leading-none">${def.emoji}</span>
        <span class="text-lg font-display font-bold text-ink leading-tight">${(counts[def.key] || 0).toLocaleString()}</span>
        <span class="text-[10px] text-ink/50 leading-tight">${def.label}</span>
      </div>
    `).join('');
  }
};


// ---------------------------------------------------------------------
// Single source of truth for category keys, used by guest-home.html, the 5
// directory pages, and business.html. Key = the `type=` value the Apps
// Script API expects (matches SHEET_MAP category keys server-side).
// ---------------------------------------------------------------------
window.CATEGORIES = {
  resorts: { label: 'Resort', page: 'resorts.html' },
  restaurants: { label: 'Restaurant', page: 'restaurants.html' },
  cafes: { label: 'Café', page: 'cafes.html' },
  surfschools: { label: 'Surf School', page: 'surf-schools.html' },
  activities: { label: 'Activity', page: 'activities.html' }
};

// ---------------------------------------------------------------------
// AppLightbox — minimal full-screen photo viewer, used by business.html's
// "tap photo to enlarge" interaction (today's stand-in for a full photo
// gallery, since listings only have one photo_url each right now).
// ---------------------------------------------------------------------
window.AppLightbox = {
  open(imgUrl, altText) {
    let overlay = document.getElementById('appLightbox');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'appLightbox';
      overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(10,37,40,0.94);display:flex;align-items:center;justify-content:center;padding:24px;cursor:zoom-out;';
      overlay.addEventListener('click', () => overlay.remove());
      document.body.appendChild(overlay);
    }
    const esc = (v) => { const d = document.createElement('div'); d.textContent = String(v ?? ''); return d.innerHTML; };
    overlay.innerHTML = `<img src="${esc(imgUrl)}" alt="${esc(altText || '')}" style="max-width:100%;max-height:100%;border-radius:12px;object-fit:contain;" />`;
  }
};


// ---------------------------------------------------------------------
// AppRating — Google rating + review count display, used on directory
// cards and business.html. Reads three optional sheet columns (any of
// which may be blank — nothing renders if `google_rating` is missing):
//   google_rating         e.g. 4.6
//   google_reviews_count  e.g. 128
//   google_maps_url       link to the listing's Google Maps page, used as
//                          the "See reviews" / "Read reviews on Google" link
// These are plain pass-through columns — see docs/API.md — so adding them
// to a directory sheet tab is enough for them to show up here, no script
// changes needed for *display*. Saving them from the Dashboard is a
// separate, smaller Code.gs change — see docs/API.md.
// ---------------------------------------------------------------------
window.AppRating = (() => {
  function esc(v) { const d = document.createElement('div'); d.textContent = String(v ?? ''); return d.innerHTML; }

  function starsHtml(rating, sizeClass = 'w-3.5 h-3.5') {
    // 5 stars, each rendered fully filled, half, or empty based on `rating`.
    let html = '';
    for (let i = 1; i <= 5; i++) {
      const filled = rating >= i - 0.25;
      const half = !filled && rating >= i - 0.75;
      html += `<i data-lucide="star" class="${sizeClass} ${filled ? 'text-sunset fill-sunset' : half ? 'text-sunset fill-sunset opacity-50' : 'text-ink/15'}"></i>`;
    }
    return html;
  }

  // Compact badge for directory cards: ★ 4.6 (128)
  function badge(item) {
    const rating = parseFloat(item.google_rating);
    if (isNaN(rating)) return '';
    const count = parseInt(item.google_reviews_count, 10);
    const countText = !isNaN(count) && count > 0 ? ` (${count})` : '';
    return `<span class="inline-flex items-center gap-1 text-xs font-semibold text-ink/80">
        <i data-lucide="star" class="w-3.5 h-3.5 text-sunset fill-sunset"></i>${rating.toFixed(1)}${countText}
      </span>`;
  }

  // Fuller block for business.html: star row + numeric rating + review
  // count + optional "Read reviews on Google" link.
  function block(item) {
    const rating = parseFloat(item.google_rating);
    if (isNaN(rating)) return '';
    const count = parseInt(item.google_reviews_count, 10);
    const countText = !isNaN(count) && count > 0 ? `${count} Google review${count === 1 ? '' : 's'}` : 'Google rating';
    const link = item.google_maps_url
      ? `<a href="${esc(item.google_maps_url)}" target="_blank" rel="noopener" class="text-ocean font-semibold underline">See on Google</a>`
      : '';
    return `<div class="flex flex-wrap items-center gap-2 mb-3">
        <div class="flex items-center gap-0.5">${starsHtml(rating, 'w-4 h-4')}</div>
        <span class="font-bold text-sm">${rating.toFixed(1)}</span>
        <span class="text-sm text-ink/50">·</span>
        <span class="text-sm text-ink/60">${esc(countText)}</span>
        ${link ? `<span class="text-sm text-ink/30">·</span>${link}` : ''}
      </div>`;
  }

  return { badge, block, starsHtml };
})();


// ---------------------------------------------------------------------
// AppAmenities — renders the optional `amenities` sheet column (a plain
// comma-separated string, e.g. "Free Wifi, Pool, Air Conditioning, Beach
// Access") as icon chips. Unknown amenity names still render fine, just
// with a generic checkmark icon — the list of names is not a fixed enum.
// ---------------------------------------------------------------------
window.AppAmenities = (() => {
  const ICON_MAP = [
    [/wifi|wi-fi/i, 'wifi'],
    [/park/i, 'car'],
    [/pool/i, 'waves'],
    [/air.?con|\bac\b/i, 'snowflake'],
    [/breakfast/i, 'coffee'],
    [/restaurant|dining/i, 'utensils'],
    [/bar\b/i, 'martini'],
    [/pet/i, 'dog'],
    [/beach/i, 'umbrella'],
    [/board|rental|gear|equipment/i, 'package'],
    [/locker/i, 'lock'],
    [/shower/i, 'droplets'],
    [/hot water/i, 'flame'],
    [/laundry/i, 'shirt'],
    [/family/i, 'users'],
    [/wheelchair|accessib/i, 'accessibility'],
    [/card|cashless|gcash/i, 'credit-card'],
    [/spa|massage/i, 'sparkles'],
    [/kitchen/i, 'cooking-pot'],
    [/gym|fitness/i, 'dumbbell'],
    [/security|guard/i, 'shield-check'],
    [/aircon.*fan|fan/i, 'fan'],
    [/tour|guide/i, 'compass'],
    [/lounge/i, 'sofa'],
    [/24|hour/i, 'clock']
  ];

  function iconFor(name) {
    const match = ICON_MAP.find(([re]) => re.test(name));
    return match ? match[1] : 'check-circle';
  }

  function esc(v) { const d = document.createElement('div'); d.textContent = String(v ?? ''); return d.innerHTML; }

  // Splits "Free Wifi, Pool,,  Air Conditioning" into ["Free Wifi","Pool","Air Conditioning"]
  function parse(raw) {
    return String(raw || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
  }

  // Compact chips for directory cards — capped at `max`, with a "+N" chip
  // for anything beyond that so cards don't grow unpredictably tall.
  function cardChips(raw, max = 3) {
    const list = parse(raw);
    if (list.length === 0) return '';
    const shown = list.slice(0, max);
    const extra = list.length - shown.length;
    const chips = shown.map((name) => `
        <span class="inline-flex items-center gap-1 text-[11px] font-semibold bg-ink/5 text-ink/70 px-2 py-1 rounded-full">
          <i data-lucide="${iconFor(name)}" class="w-3 h-3"></i>${esc(name)}
        </span>`).join('');
    const moreChip = extra > 0
      ? `<span class="inline-flex items-center text-[11px] font-semibold bg-ink/5 text-ink/50 px-2 py-1 rounded-full">+${extra} more</span>`
      : '';
    return `<div class="flex flex-wrap gap-1.5">${chips}${moreChip}</div>`;
  }

  // Full list for business.html — every amenity, larger touch-friendly chips.
  function fullChips(raw) {
    const list = parse(raw);
    if (list.length === 0) return '';
    return `<div class="flex flex-wrap gap-2">${list.map((name) => `
        <span class="inline-flex items-center gap-1.5 text-xs font-semibold bg-ocean/8 text-ocean px-3 py-1.5 rounded-full">
          <i data-lucide="${iconFor(name)}" class="w-3.5 h-3.5"></i>${esc(name)}
        </span>`).join('')}</div>`;
  }

  return { parse, iconFor, cardChips, fullChips };
})();


// ---------------------------------------------------------------------
// AppFavorites — NOT a real Favorites feature (no account/backend storage
// exists for this, by design — see docs/API.md). This is a small,
// device-only "save for later" toggle using localStorage, so the
// favorite button in card designs isn't a dead element. Tapping it also
// fires the FAVORITE analytics event (Analytics.gs already supports it).
// If a real cross-device Favorites feature gets built later, this can be
// swapped out without changing any card markup.
// ---------------------------------------------------------------------
window.AppFavorites = (() => {
  const KEY = 'liwliwa_favorites';

  function getAll() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || '[]');
    } catch (e) {
      return [];
    }
  }

  function isFavorited(businessId) {
    return getAll().includes(businessId);
  }

  function toggle(businessId) {
    if (!businessId) return false;
    const all = getAll();
    const idx = all.indexOf(businessId);
    let nowFavorited;
    if (idx === -1) {
      all.push(businessId);
      nowFavorited = true;
      AppAnalytics.track(businessId, 'FAVORITE');
    } else {
      all.splice(idx, 1);
      nowFavorited = false;
    }
    try { localStorage.setItem(KEY, JSON.stringify(all)); } catch (e) { /* storage blocked — toggle still works this session */ }
    return nowFavorited;
  }

  return { isFavorited, toggle };
})();


// Registers sw.js so the site can be installed and used offline. Loaded here
// (not per-page) because js/main.js is already included on every page — see
// sw.js itself for what gets cached and how to bump the cache after edits.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      console.warn('Service worker registration failed:', err);
    });
  });
}
// Handles icon rendering, the header's transparent-to-solid transition on
// index.html, and highlighting the active bottom nav tab (visual only —
// each page already marks its own active tab, this just keeps icons in sync).

// Top progress bar element — created immediately (body exists by the time this
// script tag runs, even before DOMContentLoaded fires), so it's ready for any
// page that calls AppProgress.start() as soon as its own script runs.
if (!document.getElementById('appProgressBar')) {
  const bar = document.createElement('div');
  bar.id = 'appProgressBar';
  document.body.appendChild(bar);
}

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    lucide.createIcons();

    // Auto-refresh icons whenever the DOM changes — covers search results,
    // listing grids, featured cards, or anything else rendered dynamically
    // later, without every render function needing to remember to call
    // lucide.createIcons() itself.
    let iconRefreshTimer = null;
    const iconObserver = new MutationObserver(() => {
      clearTimeout(iconRefreshTimer);
      iconRefreshTimer = setTimeout(() => lucide.createIcons(), 50);
    });
    iconObserver.observe(document.body, { childList: true, subtree: true });
  }

  // Header gains a subtle hairline border once you've scrolled a bit — index.html only.
  const isIndexPage = /(^|\/)index\.html$/.test(window.location.pathname) || window.location.pathname === '/' || window.location.pathname.endsWith('/');
  const header = document.getElementById('siteHeader');
  if (isIndexPage && header) {
    const toggleHeader = () => {
      header.classList.toggle('solid', window.scrollY > 8);
    };
    toggleHeader();
    window.addEventListener('scroll', toggleHeader, { passive: true });
  }
});

// Shared helper: renders N shimmer placeholder cards into a grid container,
// matching the shape of the real listing cards (photo + a couple of text lines).
// Used by resorts/restaurants/cafes/activities/surf-schools while their first
// fetch is still in flight, so the screen reads as "loading" not "frozen".
window.AppSkeleton = {
  cardGrid(container, count = 6) {
    if (!container) return;
    let html = '';
    for (let i = 0; i < count; i++) {
      html += `
        <div class="bg-white border border-ink/10 rounded-2xl overflow-hidden flex flex-col">
          <div class="skel w-full h-44"></div>
          <div class="p-5 flex flex-col gap-3">
            <div class="skel skel-line" style="width:65%; height:1.1rem;"></div>
            <div class="skel skel-line" style="width:90%;"></div>
            <div class="skel skel-line" style="width:45%;"></div>
          </div>
        </div>`;
    }
    container.innerHTML = html;
    container.classList.remove('hidden');
  },
  row(container, count = 3, heightClass = 'h-16') {
    if (!container) return;
    let html = '';
    for (let i = 0; i < count; i++) {
      html += `<div class="skel ${heightClass} rounded-xl mb-2"></div>`;
    }
    container.innerHTML = html;
  }
};
// Shared helper: call AppProgress.start() right before a fetch, AppProgress.done()
// once it resolves (success or fail). Safe to call from any page — it no-ops
// gracefully if the bar element isn't in the DOM yet for some reason.
window.AppProgress = (() => {
  let activeCount = 0;
  function bar() { return document.getElementById('appProgressBar'); }
  return {
    start() {
      activeCount++;
      const el = bar();
      if (!el) return;
      el.classList.add('active');
      el.style.width = '15%';
      requestAnimationFrame(() => { el.style.width = '70%'; });
    },
    done() {
      activeCount = Math.max(0, activeCount - 1);
      const el = bar();
      if (!el) return;
      el.style.width = '100%';
      setTimeout(() => {
        if (activeCount === 0) {
          el.classList.remove('active');
          setTimeout(() => { if (activeCount === 0) el.style.width = '0%'; }, 300);
        }
      }, 200);
    }
  };
})();
