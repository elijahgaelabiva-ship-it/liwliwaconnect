# Liwliwa Connect

An all-in-one digital tourism platform for Liwliwa, San Felipe, Zambales — connecting guests
with resorts, restaurants, cafés, surf schools, rental shops, local businesses, and the tourism office.

Built and maintained entirely from an Android phone. No paid tools.

## Tech Stack (all free)

| Layer | Tool |
|---|---|
| Frontend | HTML, CSS, JavaScript |
| Styling | Tailwind CSS (via CDN — no build step) |
| Icons | Lucide Icons (via CDN) |
| Maps | Leaflet + OpenStreetMap |
| Backend | Google Apps Script |
| Database | Google Sheets |
| Auth | Google Sign-In (added when needed) |
| Hosting | Netlify (free tier) |
| Version control | GitHub (free) |

## Project Structure

```
liwliwa-connect/
├── index.html          ← Landing page
├── css/
│   └── style.css       ← Custom styles (Tailwind handles the rest)
├── js/
│   └── main.js         ← Landing page interactivity
├── docs/                ← All project documentation (this folder)
│   ├── PROJECT_STATUS.md
│   ├── ROADMAP.md
│   ├── FEATURES.md
│   ├── DATABASE.md
│   ├── API.md
│   ├── CHANGELOG.md
│   ├── BUGS.md
│   ├── NEXT_TASK.md
│   └── NEXT_PROMPT.md
└── README.md            ← You are here
```

## How to run it (from your phone)

There's no install step. This is a static site.

1. Open `index.html` in any mobile browser (Chrome, etc.) — either by opening the file
   directly, or by uploading the project to Netlify (see below).
2. Everything loads from free CDNs (Tailwind, Lucide, Google Fonts), so you need internet
   access the first time it loads, but no build tools.

## Deploying to Netlify (free)

1. Push this project to a GitHub repository.
2. On Netlify, choose **"Add new site" → "Import an existing project"**.
3. Connect your GitHub account and pick this repo.
4. Leave build settings blank (no build command, publish directory = root `/`).
5. Deploy. Netlify gives you a free `.netlify.app` URL.

## Where to start reading

If you're picking this project up (including a fresh Claude session), read in this order:
1. `docs/PROJECT_STATUS.md` — what's done, what's next
2. `docs/NEXT_TASK.md` — the very next thing to build
3. `docs/FEATURES.md` — full feature list and status
