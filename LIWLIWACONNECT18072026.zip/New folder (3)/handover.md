Continue development of Liwliwa Connect — a tourism directory site for Liwliwa, San Felipe,
Zambales, built entirely from an Android phone, using free tools only (HTML/Tailwind/Lucide
frontend, Google Sheets + Apps Script backend, Netlify hosting).

READ FIRST, in order: docs/PROJECT_STATUS.md, docs/API.md, docs/NEXT_TASK.md. These contain
the full accurate state as of 2026-07-10. This handover covers what changed AFTER that in the
2026-07-11 session — read this too, since it corrects/updates a few things below.

STATUS SUMMARY:
- Phase 1 (10 features) complete and confirmed live.
- Phase 2 core loop CONFIRMED WORKING end to end: Business Registration (with email
  verification) → Admin approval → listing goes live → owner Dashboard login → edits go
  through a SECOND admin approval step before going live. The MailApp re-authorization issue
  that was blocking registration is now RESOLVED — user confirmed registration works.
- No CORS/JSONP pivot happened. A prior handover incorrectly described one; user checked the
  live Apps Script directly and confirmed it still uses plain fetch()/doGet+doPost, no JSONP,
  no "callback" anywhere. Ignore any future doc or memory that references a JSONP pivot unless
  re-confirmed against the actual deployed script.
- docs/API.md is known to be one step behind the deployed Apps Script: the deployed script DOES
  contain submit_edit/approve_edit/reject_edit/pending_edits (user confirmed by checking the
  Apps Script editor directly), but the script pasted in API.md is the older version without
  them. Not urgent, but API.md should be refreshed from the real script next time there's a
  reason to touch the backend, rather than assumed accurate as-is.

VISUAL REDESIGN / STRUCTURE CHANGE (2026-07-11 session):
- index.html was restructured at the user's request: removed the hamburger/mobile-menu icon
  entirely (nav links are now always visible, no toggle), and removed all in-page anchor
  scrolling. The user explicitly does not want scroll-to-section navigation — every nav item
  and CTA must be a direct link to its own page.
- The old "Directories" bento section (Resorts/Restaurants/Cafés/Surf Schools/Activities/Map
  cards) was removed from index.html — guest-home.html already covers this via the "Explore"
  link, so it was redundant rather than rebuilt elsewhere.
- The old "For Businesses" section was split out into a new page, for-business-owners.html,
  reusing the same content/copy. index.html's hero button, nav link, and every other page's
  "For Businesses" nav link were all repointed from index.html#for-businesses to
  for-business-owners.html.
- index.html's hero photo is set via PHOTO_URLS (still the same self-service pattern, just
  simplified to hero-only since the photo cards moved off this page). Current hero photo:
  https://i.postimg.cc/mk87Mxz0/download.jpg — hosted on postimages.org, not imgur, because the
  user found imgur's UI too hard to navigate for getting a direct link. Prefer postimages.org
  for any future photo requests — walk the user through: postimages.org → Choose images →
  Upload it! → copy the "Direct link" box (shows immediately, no menu-hunting).
- Only index.html and for-business-owners.html have the new look/structure so far. All other
  pages (guest-home, resorts, restaurants, cafes, surf-schools, activities, map, register,
  dashboard, admin) still use the older visual style and still have their own hamburger/mobile
  menu — those were NOT touched this session and may still scroll/toggle as before. Don't
  assume they were updated to match; ask the user before changing them.

DELIVERY NOTE — IMPORTANT: earlier in this session, a single updated index.html was sent for
download twice, and the user reported "no changes" both times even after the file was verified
correct on this end. Root cause was likely the phone/browser reusing an old cached copy of a
file with the same name. Resolution: package multiple/related file changes as a zip rather than
single same-named files when re-sending updates, and tell the user to delete any old file with
the same name before opening a new download, since phones often silently keep the old one.

CRITICAL CONTEXT (carried over, still applies):
1. Google Sign-In was abandoned for the Dashboard — don't suggest it again unless asked.
2. Apps Script backend is NOT a file in this project — it lives only in the user's Google
   Sheet (Extensions → Apps Script). Re-paste from API.md if there's doubt what's deployed, but
   see the API.md staleness note above first.
3. Google Sheets auto-converts numeric-looking text into a Number, breaking === checks against
   strings from forms — already fixed via String() coercion. Watch for this in any new
   sheet-data comparison.
4. Netlify site: https://imaginative-halva-372727.netlify.app — deploy via that site's own
   Deploys tab. The older liwliwa-connect.netlify.app name is dead, ignore it.
5. User prefers concise responses — lead with the fix/action, elaborate only if asked. Zero
   coding background — explain any manual step in plain language, assume phone-only workflow.
6. Free Netlify tier: 300 credits/month, ~15/deploy — batch changes when reasonable. Apps
   Script edits are free, no batching needed there.
7. Owner listing edits require admin approval via PendingEdits — don't simplify to instant-save.

IMMEDIATE NEXT STEPS:
1. User has NOT yet pushed these index.html/for-business-owners.html changes to GitHub or
   redeployed to Netlify — confirm when they're ready to do that.
2. Ask if/when they want the same hamburger-removal + direct-link-only treatment applied to
   the other pages (guest-home, resorts, restaurants, cafes, surf-schools, activities, map,
   register, dashboard, admin) — don't assume all at once.
3. Ask which Phase 2 feature to prioritize next (Featured Listings, Promotions, Events, or
   Contact Businesses) — still undecided.
4. More real photos may be coming for other directory cards (previously handled via PHOTO_URLS
   on index.html; that mechanism moved off index.html when the directory section was removed —
   decide with the user where per-listing/per-page photos should live now, e.g. guest-home.html
   or the individual directory pages).
