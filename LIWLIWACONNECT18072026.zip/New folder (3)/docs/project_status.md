# Project Status

**Last updated:** 2026-07-10

## Phase 1 (Core Directories & Discovery): ✅ COMPLETE

All 10 features built, deployed, and confirmed working: Landing Page, Guest Home, 5
directories (Resorts, Restaurants, Cafés, Surf Schools, Activities), Interactive Map, Search,
Filters.

## Phase 2 (Business Tools): 🔧 In progress

| Feature | Status |
|---|---|
| 12. Business Registration | ✅ CONFIRMED — includes email verification (6-digit code) + rate limiting |
| 13. Admin Panel | ✅ CONFIRMED — login, approve/reject businesses AND listing edits |
| 11. Business Dashboard | ✅ CONFIRMED — email+password login, edits go to review queue (not live instantly) |
| 14. Featured Listings | ✅ Done |
| 15. Promotions | ⬜ Not started |
| 16. Events | ⬜ Not started |
| 17. Contact Businesses | ⬜ Not started |
| 18. Business Analytics | 🔧 Built, **not live yet** — needs a 3-part Code.gs patch pasted in (see below) |
| 19. Amenities + Google Reviews display | 🔧 Frontend done (all 5 directory cards, business.html, register.html, dashboard.html) — reads `amenities`, `google_rating`, `google_reviews_count`, `google_maps_url` columns. **Needs 2 sheet/script changes to fully persist, see docs/API.md**: (1) add these 4 columns to the 5 directory sheets + Businesses tab, (2) add `amenities` to `register`'s appendRow array and `update_listing`'s `updatable` whitelist in Code.gs. `google_rating`/`google_reviews_count`/`google_maps_url` are admin/sheet-only by design (not owner-editable), kept in sync with the real Google Maps listing. |

**Full confirmed working cycle:** Register → email code verification → Admin approves →
listing goes live → owner logs into Dashboard → edits → Admin approves the edit → change goes live.

## Visual redesign: 🔧 In progress (index.html only so far)

User requested a premium travel-app look (Airbnb/Traveloka/Booking.com inspired), then
refined the direction toward a vivid turquoise-water/sand aesthetic after seeing reference
photos. Only `index.html` has been redesigned — all other pages still use the original visual
style and will look inconsistent until redesigned in later passes. This is expected.

**Design system added** (`css/style.css`, additive only — nothing removed): `.card-premium`,
`.glass-pill`, `.glass-card-light`, `.price-pill`, `.icon-chip`, `.btn-pill-primary`,
`.btn-pill-outline`. New color tokens: `mint`, `ocean`, `turquoise`, `lagoon`, `sandWarm`.

**Self-service photo system built into index.html:** a `PHOTO_URLS` block (clearly commented,
near the bottom of the file) lets the user paste direct image links (via Imgur) to replace the
hero background and all 6 directory card backgrounds — currently gradient placeholders. A
small script applies whichever URLs are filled in; empty ones keep the gradient. **Reuse this
exact pattern if adding photos to other pages later — don't invent a new mechanism.**

**Not yet done:** user hasn't uploaded real photos yet (said they would). Other pages
(guest-home, dashboard, admin, 5 directories, map, register) not yet redesigned.

## Business Analytics System (added 2026-07-12)

Tracks guest interactions per listing (views, calls, directions, website/social clicks,
shares, gallery/event opens). Analytics only — not a booking system. Full design/endpoints in
`API.md` "Analytics" section.

**Built:**
- `Analytics.gs` — new Apps Script file (logAnalytics, getBusinessAnalytics,
  getAnalyticsSummary + helpers + caching). Not yet pasted into the live Apps Script project.
- `js/main.js` — `AppAnalytics` (client tracking, fire-and-forget, never blocks the action
  it's attached to), `AppChart`/`AppAnalyticsCards` (lightweight, no-library charts/cards),
  `AppLightbox` (full-screen photo viewer), `CATEGORIES` (shared category label/page map,
  replacing 3 near-identical copies of the same object across guest-home/directory/business
  pages).
- **`business.html`** — new business profile page. Automatically logs `VIEW` on load (no
  button tap needed). Has Call, Directions (if lat/lng set), Website, Facebook, Instagram (if
  set), Share (native share sheet), and tap-photo-to-enlarge (logs `PHOTO_VIEW`). Reachable
  from directory cards, guest-home's featured cards + search results, and shared links.
- All 5 directory pages — cards now link to `business.html`; Call/Facebook buttons still work
  standalone and still track `CALL`/`FACEBOOK` directly from the card too.
- Dashboard.html — Analytics section per listing (Today/7D/30D/All + 10 summary cards + Views
  by day chart), gated by that listing's own owner login. Edit form also gained Website,
  Instagram, Latitude, and Longitude fields (lat/lng existed for the map but had no edit UI
  until now).
- Register.html — Website and Instagram fields added to the signup form.
- Admin.html — sitewide Analytics section (cards + Top viewed/Most clicked/Most shared
  leaderboards), gated by the admin password; pending-edits queue now labels the new fields.

**Not live yet — requires action from the user:**
1. Paste `Analytics.gs` into the Apps Script editor as a new file.
2. Apply the 3-part Code.gs patch in `API.md` (route analytics requests; add an `id` field to
   public listings so there's a BusinessID to track against; add `id` to dashboard_login).
   Until this is done, `business.html` shows "Couldn't find this business" for every link, and
   tracking calls no-op harmlessly (no `id` to send).
3. Add `website_url` and `instagram_url` columns to the 5 directory sheets (existing rows can
   stay blank).
4. **Unverified:** whether `submit_edit`/`register`/`add_listing` on the live script write back
   a fixed field list or accept new fields generically. The new `website_url`, `instagram_url`,
   `latitude`, `longitude` fields might silently not save until this is checked — see API.md
   for details. Nothing breaks either way, they just may not persist until confirmed.

**Deliberately not built:** `EVENT_CLICK` has nothing to attach to — there's no Events feature
anywhere in the app (Phase 2 item #16, not started). `FAVORITE` is still correctly just a hook
(`logFavoriteHook_` in Analytics.gs) — Favorites itself hasn't been built, per the original
instructions to prepare the hook only.

## Mobile App V2 redesign (started 2026-07-13)

Full visual redesign requested — "make it look/feel like a native Android app (Airbnb/Booking/
Grab-style)." Backend, data, and all existing functionality are unchanged; this is UI-only.

**Tech-stack reality check** (the brief assumed a different stack — noted here so it's not
re-litigated later): no Supabase (backend is Google Sheets + Apps Script); no React/Framer
Motion (static HTML + Tailwind CDN + vanilla JS, no build step — CSS transitions/animations
stand in for Framer Motion); not a native Android binary (it's a PWA — installable and
offline-capable already, but "Play Store" would need a separate wrapping step like a Trusted
Web Activity, not just a UI change).

**New design system** — additive in `css/style.css` under "MOBILE APP V2" (doesn't touch any
class the old design still uses, so unconverted pages are unaffected): floating pill-shaped
bottom nav (`.floating-nav`), horizontal-scroll chips/carousels (`.hscroll`, `.chip`), gradient
buttons (`.btn-gradient`), app-style cards (`.card-app`), a favorite button, and fade-in-on-load
animation utilities. New color tokens per-page (`ocean`/`turquoise`/`sunset`/`mist`/`ink`) —
each converted page declares these in its own `tailwind.config` block, same pattern the old
palette used (there's no shared config file; Tailwind CDN requires it per-page).

**New:** `AppFavorites` in `js/main.js` — a small, honest, device-only "save for later" toggle
(localStorage, not an account feature — Favorites itself still isn't built, per the original
instruction to only prepare the hook). Wired to the existing `FAVORITE` analytics event.

**Converted (all pages now on the new design system):**
- `index.html` — Welcome screen: full-bleed edge-to-edge hero, gradient overlay, single CTA, fade-in.
- `guest-home.html` — Home/Discover screen: gradient header, rounded search, category chips,
  horizontal Featured carousel, floating bottom nav.
- `resorts.html` / `restaurants.html` / `cafes.html` / `surf-schools.html` / `activities.html` —
  gradient header with chip filters, `.card-app` listing cards with favorite buttons, floating
  bottom nav. All 5 share one template (they were already near-identical) — same fetch calls,
  same filter/highlight logic, same `business.html` links, untouched.
- `business.html` — profile page restyled (gradient action buttons, `.card-app`-style hero),
  every analytics event/action (Call/Directions/Website/Facebook/Instagram/Share/PhotoView)
  and the automatic VIEW-on-load still fire exactly as before.
- `map.html` — restyled header/legend/nav; Leaflet map, markers, and popups untouched. Marker
  colors updated to the new palette (resorts=sunset, restaurants=ocean, cafes=turquoise,
  surfschools=oceanDeep, activities=violet).
- `register.html` — filled-style rounded inputs; the whole send_code → register verification
  flow (field names, actions) is untouched.
- `dashboard.html` — filled inputs, gradient buttons, `.card-app` listing cards; every field
  name, action (`dashboard_login`/`submit_edit`/`add_listing`), and the per-listing Analytics
  section (range toggle, cards, chart) work exactly as before — just restyled.
- `admin.html` — gradient headers, `.card-app` queues; `approve`/`reject`/`approve_edit`/
  `reject_edit` and the sitewide Analytics section are untouched.
- `for-business-owners.html`, `404.html`, `500.html` — restyled to match (gradient background,
  new type).
- `offline.html` — restyled colors/font, but deliberately kept **fully self-contained** (no
  CDN, no Tailwind) since it must render with zero internet; the wave emoji was swapped for an
  inline SVG icon per the redesign's "no emoji" rule, without adding any external dependency.

**Not converted, and not applicable:** none — every page in the project now uses the new
design system.

**On the Supabase/Framer Motion/native-Android points from the original brief:** unchanged
from what was already flagged when this started — this project has no Supabase (Google Sheets +
Apps Script), no React/Framer Motion (CSS transitions do the equivalent job), and isn't a
native Android binary (it's the existing PWA, just restyled). See "Tech-stack reality check"
above for the full explanation — nothing about that changed by finishing the rollout.

## Guest Safety & Local Info pages (added 2026-07-14)

Two new guest-facing pages, same visual system as `getting-here.html`:

- **`emergency-help.html`** — leads with a tel:911 call button, then local San Felipe contacts
  (Police, Clinic, Rescue/MDRRMO, Towing) as tap-to-call cards. Police number is filled in
  (San Felipe Municipal Police Station). Clinic/Rescue/Towing don't have a confirmed public
  phone number yet, so they show "See map" / "Ask your resort" instead of a wrong number —
  each has an `<!-- EDIT ME -->` comment in the HTML showing exactly how to swap in a real
  `tel:` link once you've confirmed one with the municipal hall. **Don't guess a phone number
  here** — a wrong emergency contact is worse than none.
- **`beach-etiquette.html`** — environmental reminders (trash, corals/shells, reef-safe
  sunscreen, bonfires) and local rules (quiet hours, swimwear off the beach, swim
  advisories, the eco-tourism fee already mentioned in Getting Here).

Both linked from `guest-home.html`: two new chips in the category row, and a 2-up "Good to
know" card row placed right under the existing Getting Here CTA. Both use the standard
floating bottom nav, no new backend/data needed — fully static.

## Netlify

Live site: **https://imaginative-halva-372727.netlify.app** (the original site,
liwliwa-connect.netlify.app, ran out of free credits and was abandoned — ignore that name if
it appears anywhere in older doc history). Free plan, 300 credits/month, ~15 per deploy.
Deploy via that site's own Deploys tab, never Netlify's generic `/drop` page.

## Database

Google Sheet "Liwliwa Connect DB", 7 tabs: Resorts, Restaurants, Cafes, SurfSchools,
Activities (identical schema, 11 columns each incl. owner_email/owner_password), Businesses
(registration queue), PendingEdits (auto-created, edit review queue). Full schema in `DATABASE.md`.

## ⚠️ CRITICAL: Apps Script lives OUTSIDE this project's files

The Apps Script (Code.gs) is pasted directly into the user's Google Sheet — NOT a file in this
zip. **`API.md` is always the canonical current version.** This script has been revised many
times (Google Sign-In attempt → abandoned → password-based → +email verification +rate
limiting → +String() coercion bugfix → +edit approval queue). Always re-paste from API.md if
unsure what's deployed.

## Known bugs

None currently open. Notable fixed bug: Google Sheets auto-converts numeric-looking text
(e.g. a password like "123456") into a Number, breaking `===` comparisons against strings from
forms — fixed by wrapping all such comparisons in `String()`. Watch for this in any future
sheet-data comparison. Full history in `BUGS.md`.

## Known limitations (accepted for MVP scale, discussed with user)

- Passwords stored as plain text in the spreadsheet
- No CAPTCHA (mitigated by admin approval + email verification + rate limiting)
- Google Sign-In was tried and fully abandoned due to OAuth config issues — **do not suggest
  re-adding it unless the user explicitly asks**

## User preferences (important for tone/workflow)

- Prefers concise responses — lead with the fix/action, elaborate only if asked
- Prefers batching Netlify deploys (free tier credits) over deploying after every small change
- Google Apps Script edits are free and don't need batching
- Zero coding background — explain steps in plain language, assume phone-only workflow

## Files in this project

`index.html` (redesigned), `guest-home.html`, `resorts.html`, `restaurants.html`,
`cafes.html`, `surf-schools.html`, `activities.html`, `business.html` (business profile page),
`map.html`, `register.html`, `admin.html`, `dashboard.html`, `for-business-owners.html`
(redesigned), `404.html`, `500.html`, `offline.html`, `sw.js` (service worker — offline
support), `manifest.json`, `Analytics.gs` (paste into Apps Script as a new file — see above),
`css/style.css`, `js/main.js`, `icons/`, `docs/*.md`

## Immediate next steps (pick up here)

1. **🐛 Waiting on user, urgent:** paste the fixed `approve` handler from `API.md` "Bug fixes"
   section into the live Code.gs — approved businesses were never actually copying into their
   directory tab (or guest-home), just silently marked "approved" and lost. Also check
   Resorts/Restaurants/etc. for any already-approved rows that came out broken from the old bug.
2. **Waiting on user:** paste `Analytics.gs` into Apps Script + apply the 3-part Code.gs patch
   in `API.md`, to bring the new Business Analytics System live
3. **Waiting on user:** real photos of Liwliwa to drop into the PHOTO_URLS system
4. **Design:** redesign remaining pages to match index.html's new premium look, once the
   design direction is validated with real photos
5. **Features:** decide with user which Phase 2 feature comes next (Featured Listings,
   Promotions, Events, or Contact Businesses)
