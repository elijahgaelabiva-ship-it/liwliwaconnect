# API — Apps Script (single source of truth)

**This script lives in the Google Sheet's Extensions → Apps Script editor (Code.gs), NOT as a
file in this project.** The version below is the current, correct, deployed version as of
2026-07-09. If in doubt, re-paste this whole thing and redeploy as a new version of the
existing deployment (same URL, never create a new deployment).

Deployment settings: **Execute as: Me**, **Who has access: Anyone**.

Base URL: `https://script.google.com/macros/s/AKfycbx1doFh9X93nSzMbxtDFmOUWEDf8MoT7Csb8XiEmKnh7Zw33RDEDjN8N7WlSFTMS5gb/exec`

Admin password (change the constant in the script if needed): `liwliwa2026`

## Endpoints (GET)

- `?type=resorts|restaurants|cafes|surfschools|activities` — one directory's listings (owner_email/owner_password stripped from response)
- `?type=all` — all 5 directories combined, each item tagged with `category` (used by map.html and search)
- `?type=businesses&password=ADMIN_PASSWORD` — all registration submissions, admin-only

## Endpoints (POST, JSON body, Content-Type: text/plain;charset=utf-8)

- `{action: 'send_code', email}` — emails a 6-digit code, rate-limited to 3/email/hour
- `{action: 'register', code, ...all registration fields...}` — finalizes registration IF code matches; appends to Businesses tab with status "pending"
- `{action: 'approve', row, password}` / `{action: 'reject', row, password}` — admin-only; approve copies the row into the matching directory tab (including owner_email/owner_password) and marks it approved
- `{action: 'dashboard_login', email, password}` — returns all listings across all 5 directory tabs matching that email+password
- `{action: 'update_listing', email, password, category, row, fields: {...}}` — edits one listing, only if email+password match that row's owner_email/owner_password

## Full current script

```javascript
const ADMIN_PASSWORD = 'liwliwa2026';

const SHEET_MAP = {
  resorts: 'Resorts', restaurants: 'Restaurants', cafes: 'Cafes',
  surfschools: 'SurfSchools', activities: 'Activities'
};

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  if (e.parameter.type === 'businesses') {
    if (e.parameter.password !== ADMIN_PASSWORD) return jsonOut({ error: 'unauthorized' });
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Businesses');
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const results = data.slice(1).map(function(row, i) {
      const item = { row: i + 2 };
      headers.forEach(function(h, j) { item[h] = row[j]; });
      return item;
    }).filter(function(item) { return item.business_name; });
    return jsonOut(results);
  }

  if (e.parameter.type === 'all') {
    const all = [];
    Object.keys(SHEET_MAP).forEach(function(key) {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MAP[key]);
      if (!sheet) return;
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      data.slice(1).filter(function(row){ return row[0]; }).forEach(function(row) {
        const item = { category: key };
        headers.forEach(function(header, i) { if (header !== 'owner_email' && header !== 'owner_password') item[header] = row[i]; });
        all.push(item);
      });
    });
    return jsonOut(all);
  }

  const sheetName = SHEET_MAP[e.parameter.type] || 'Resorts';
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) return jsonOut({ error: 'Sheet tab "' + sheetName + '" not found' });
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const results = data.slice(1).filter(function(row){ return row[0]; }).map(function(row) {
    const item = {};
    headers.forEach(function(header, i) { if (header !== 'owner_email' && header !== 'owner_password') item[header] = row[i]; });
    return item;
  });
  return jsonOut(results);
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();

    if (data.action === 'send_code') {
      const cache = CacheService.getScriptCache();
      const attemptsKey = 'attempts_' + data.email;
      const attempts = parseInt(cache.get(attemptsKey) || '0');

      if (attempts >= 3) {
        return jsonOut({ success: false, error: 'Too many attempts. Please try again in an hour.' });
      }

      cache.put(attemptsKey, String(attempts + 1), 3600);

      const code = Math.floor(100000 + Math.random() * 900000).toString();
      cache.put('code_' + data.email, code, 600);
      MailApp.sendEmail(data.email, 'Your Liwliwa Connect verification code',
        'Your verification code is: ' + code + '\n\nThis code expires in 10 minutes. If you did not request this, ignore this email.');
      return jsonOut({ success: true });
    }

    if (data.action === 'register') {
      const cached = CacheService.getScriptCache().get('code_' + data.email);
      if (!cached || cached !== data.code) {
        return jsonOut({ success: false, error: 'Incorrect or expired code' });
      }
      CacheService.getScriptCache().remove('code_' + data.email);

      const sheet = ss.getSheetByName('Businesses');
      // Assumes an "amenities" column has been added at the very end of the
      // Businesses sheet tab (rightmost column) — appendRow is positional,
      // so the array order here must exactly match the sheet's column order.
      sheet.appendRow([
        new Date(), data.business_name || '', data.category || '', data.owner_name || '',
        data.email || '', data.contact_number || '', data.description || '',
        data.price_range || '', data.price_tier || '', data.facebook_url || '', 'pending',
        data.password || '', data.amenities || ''
      ]);
      return jsonOut({ success: true });
    }

    if (data.action === 'approve' || data.action === 'reject') {
      if (data.password !== ADMIN_PASSWORD) return jsonOut({ success: false, error: 'unauthorized' });
      const bizSheet = ss.getSheetByName('Businesses');
      const row = data.row;
      const headers = bizSheet.getRange(1, 1, 1, bizSheet.getLastColumn()).getValues()[0];
      const rowValues = bizSheet.getRange(row, 1, 1, bizSheet.getLastColumn()).getValues()[0];
      const statusCol = headers.indexOf('status') + 1;

      if (data.action === 'reject') {
        bizSheet.getRange(row, statusCol).setValue('rejected');
        return jsonOut({ success: true });
      }

      const bizObj = {};
      headers.forEach(function(h, i) { bizObj[h] = rowValues[i]; });

      const targetSheet = ss.getSheetByName(SHEET_MAP[bizObj.category]);
      if (!targetSheet) {
        // Don't mark approved if we can't actually find where to copy it —
        // this used to fail silently, leaving the business "approved" in
        // the queue but never written anywhere.
        return jsonOut({ success: false, error: 'No sheet tab found for category "' + bizObj.category + '"' });
      }

      // Build the new row by matching the TARGET sheet's own header names —
      // not a hardcoded column order — so this keeps working no matter what
      // columns Resorts/Restaurants/etc. have, including ones added later
      // (latitude, longitude, website_url, instagram_url, amenities,
      // google_rating, google_reviews_count, google_maps_url, etc.).
      // NOTE: no change needed here for amenities to flow through — as long
      // as both the Businesses tab and the target directory tab have a
      // column literally named "amenities", it copies automatically.
      const targetHeaders = targetSheet.getRange(1, 1, 1, targetSheet.getLastColumn()).getValues()[0];
      // Businesses tab calls it "business_name"; directory tabs call it "name".
      const FIELD_MAP = { name: 'business_name' };
      const newRow = targetHeaders.map(function(header) {
        const bizField = FIELD_MAP[header] || header;
        return bizObj[bizField] !== undefined ? bizObj[bizField] : '';
      });
      targetSheet.appendRow(newRow);
      bizSheet.getRange(row, statusCol).setValue('approved');
      return jsonOut({ success: true });
    }

    if (data.action === 'dashboard_login') {
      const listings = [];
      Object.keys(SHEET_MAP).forEach(function(key) {
        const sheet = ss.getSheetByName(SHEET_MAP[key]);
        const vals = sheet.getDataRange().getValues();
        const headers = vals[0];
        const emailCol = headers.indexOf('owner_email');
        const passCol = headers.indexOf('owner_password');
        if (emailCol === -1 || passCol === -1) return;
        vals.slice(1).forEach(function(row, i) {
          if (String(row[emailCol]) === String(data.email) && String(row[passCol]) === String(data.password)) {
            const item = { category: key, row: i + 2 };
            headers.forEach(function(h, j) { item[h] = row[j]; });
            listings.push(item);
          }
        });
      });
      return jsonOut({ success: listings.length > 0, listings: listings });
    }

    if (data.action === 'update_listing') {
      const sheet = ss.getSheetByName(SHEET_MAP[data.category]);
      if (!sheet) return jsonOut({ success: false, error: 'bad category' });
      const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
      const emailCol = headers.indexOf('owner_email') + 1;
      const passCol = headers.indexOf('owner_password') + 1;
      const currentEmail = sheet.getRange(data.row, emailCol).getValue();
      const currentPass = sheet.getRange(data.row, passCol).getValue();
      if (String(currentEmail) !== String(data.email) || String(currentPass) !== String(data.password)) {
        return jsonOut({ success: false, error: 'not authorized' });
      }

      // (google_rating/google_reviews_count/google_maps_url are deliberately
      // NOT owner-editable — keep those admin/sheet-only, synced with the
      // real Google Maps listing.)
      const updatable = ['description', 'price_range', 'price_tier', 'contact_number', 'facebook_url', 'photo_url', 'amenities'];
      updatable.forEach(function(field) {
        if (data.fields && data.fields[field] !== undefined) {
          const col = headers.indexOf(field) + 1;
          if (col > 0) sheet.getRange(data.row, col).setValue(data.fields[field]);
        }
      });
      return jsonOut({ success: true });
    }

    return jsonOut({ success: false, error: 'unknown action' });

  } catch (err) {
    return jsonOut({ success: false, error: err.message });
  }
}
```

## Bug fixes

### 2026-07-13 — Approved businesses weren't copying into the directory tab

**Symptom:** registering a business and approving it in admin.html made it disappear from the
"pending" queue (Businesses tab), but it never showed up in Resorts/Restaurants/etc., and
never appeared on guest-home either.

**Root cause:** the `approve` action in `doPost` built the new row with a hardcoded, positional
array (`[bizObj.business_name, bizObj.description, ...]`) instead of matching values to columns
by header name like the rest of the script does. If the target sheet's actual column order
doesn't exactly match that hardcoded guess — which it very likely doesn't, especially with
`latitude`/`longitude`/`website_url`/`instagram_url` columns now in the mix — values land in the
wrong columns or the row ends up effectively broken. On top of that, the business got marked
"approved" unconditionally, even if the target sheet lookup failed and nothing was actually
copied — so there was no error, just a silent no-op.

**Fix, already applied to the reference copy above:** the `approve` branch now reads the
target sheet's own header row and builds the new row to match those headers by name (same
pattern as `doGet` and `update_listing`), and returns an explicit error instead of marking
"approved" if no matching sheet tab is found. See the `## Full current script` block above for
the corrected code — the whole `if (data.action === 'approve' || data.action === 'reject')`
block changed.

**To apply this to your live script:** open Apps Script → Code.gs, find your existing
`if (data.action === 'approve' || data.action === 'reject') { ... }` block, and replace it
with the corrected version above. **One thing to check first:** this fix assumes your Resorts/
Restaurants/Cafes/SurfSchools/Activities tabs have a column literally named `name` (not
`business_name` — that's only the Businesses tab's name for it). If your directory tabs use a
different header for the business name, add it to the `FIELD_MAP` object in the fix (e.g.
`{ name: 'business_name', listing_title: 'business_name' }` if your directory tabs actually
call it `listing_title`).

**Already-approved businesses that got lost or miswritten** by the old buggy code won't fix
themselves — check your Resorts/Restaurants/etc. tabs for any broken/incomplete rows from past
approvals and either fix them by hand or re-add them once the patch above is live.

## Known limitations (discussed with user, accepted for MVP scale)

- Passwords stored as plain text in the spreadsheet (owner_password, ADMIN_PASSWORD)
- No CAPTCHA/bot protection on registration (mitigated by: manual admin approval + email
  verification + rate limiting)
- Anyone viewing page source can see the Apps Script URL and call it directly, bypassing the
  HTML forms — email verification and rate limiting still apply since they're enforced
  server-side, not just in the UI

## Analytics (Analytics.gs)

**New file, added 2026-07-12.** Business Analytics System — tracks guest interactions
(views, calls, directions, website/social clicks, shares, gallery/event opens) per listing.
Analytics only, not a booking system. Full implementation lives in `Analytics.gs` at the
project root — paste it into the Apps Script editor as a **new file** (the `+` next to Files
→ Script, name it `Analytics.gs`). Do not paste it into Code.gs itself.

Sheet: **Analytics** (auto-created by the script the first time any event is logged — no
manual tab/column setup needed). Columns: `Timestamp | BusinessID | EventType | GuestID |
Device | Notes`.

Event types: `VIEW, CALL, DIRECTION, WEBSITE, FACEBOOK, INSTAGRAM, SHARE, FAVORITE,
PHOTO_VIEW, EVENT_CLICK`. New types can be added freely later — EventType is a plain string
column, so nothing about the sheet or the write path needs to change.

BusinessID format: `category_row`, e.g. `resorts_14` (the same "which tab, which row" idea
`update_listing` already uses, just combined into one string). This requires public listings
to carry an `id` field, which they don't yet — see the patch below.

### Required Code.gs changes (three small, additive edits — do not replace the whole script)

**1. Route analytics requests.** In `doGet(e)`, add this as the very first line inside the
function:
```javascript
function doGet(e) {
  const analyticsResponse = handleAnalyticsGet_(e);
  if (analyticsResponse) return analyticsResponse;

  // ...rest of doGet unchanged...
```
In `doPost(e)`, add this right after `const data = JSON.parse(e.postData.contents);`:
```javascript
    const analyticsResponse = handleAnalyticsPost_(data);
    if (analyticsResponse) return analyticsResponse;
```
Both helper functions live in Analytics.gs and return `null` for anything that isn't an
analytics request, so the rest of doGet/doPost runs exactly as before.

**2. Expose a stable `id` on public listings**, so the frontend has something to send as
BusinessID. In `doGet(e)`, replace the per-type block:
```javascript
  const sheetName = SHEET_MAP[e.parameter.type] || 'Resorts';
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) return jsonOut({ error: 'Sheet tab "' + sheetName + '" not found' });
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const results = data.slice(1).filter(function(row){ return row[0]; }).map(function(row) {
    const item = {};
    headers.forEach(function(header, i) { if (header !== 'owner_email' && header !== 'owner_password') item[header] = row[i]; });
    return item;
  });
  return jsonOut(results);
```
with:
```javascript
  const sheetName = SHEET_MAP[e.parameter.type] || 'Resorts';
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) return jsonOut({ error: 'Sheet tab "' + sheetName + '" not found' });
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const results = [];
  data.slice(1).forEach(function(row, i) {
    if (!row[0]) return;
    const item = { id: e.parameter.type + '_' + (i + 2) };
    headers.forEach(function(header, j) { if (header !== 'owner_email' && header !== 'owner_password') item[header] = row[j]; });
    results.push(item);
  });
  return jsonOut(results);
```
And the `type === 'all'` block:
```javascript
  if (e.parameter.type === 'all') {
    const all = [];
    Object.keys(SHEET_MAP).forEach(function(key) {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MAP[key]);
      if (!sheet) return;
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      data.slice(1).forEach(function(row, i) {
        if (!row[0]) return;
        const item = { category: key, id: key + '_' + (i + 2) };
        headers.forEach(function(header, j) { if (header !== 'owner_email' && header !== 'owner_password') item[header] = row[j]; });
        all.push(item);
      });
    });
    return jsonOut(all);
  }
```
(This changes `.filter().map()` to a single `.forEach()` with an early return — same result,
but keeps the correct sheet row number for `id` even if a blank row is ever skipped.)

**3. Add the same `id` to `dashboard_login`'s response** (optional but recommended, for
consistency — the dashboard can compute `category + '_' + row` itself if this is skipped).
In the `dashboard_login` block, change:
```javascript
            const item = { category: key, row: i + 2 };
```
to:
```javascript
            const item = { category: key, row: i + 2, id: key + '_' + (i + 2) };
```

### New endpoints

- `?type=business_analytics&id=BUSINESS_ID&range=today|7d|30d|all&email=...&password=...` —
  one business's analytics. Gated by that business's own owner_email/owner_password (same
  rule as `update_listing`), so owners can't see each other's numbers. Returns
  `{ businessId, range, counts: {VIEW: n, CALL: n, ...}, total, dailySeries: {"2026-07-12": n, ...} }`
- `?type=analytics_summary&range=today|7d|30d|all&password=ADMIN_PASSWORD` — sitewide, admin
  only. Returns the same shape plus `topViewed`, `mostClicked`, `mostShared` — each an array
  of up to 5 `{ businessId, name, count }`.
- `{action: 'log_analytics', businessId, eventType, guestId, device, notes}` (POST) — logs one
  event. Always responds `{success: true}` regardless of whether the write actually landed;
  the frontend never reacts to this response either way (see js/main.js `AppAnalytics.track`,
  fire-and-forget by design).

### What's wired up on the frontend — see "Business profile page" below

This used to say there was no business profile page and most event types had nothing to
attach to. That's no longer true — see the next section for the current state.

## Business profile page (business.html) — added 2026-07-12

The missing piece the Analytics event types needed: a page a guest actually "opens,"
reachable as `business.html?id=BUSINESS_ID` from directory cards, guest-home's featured cards
and search results, or a shared link (the Share button's whole point). Fetches the business by
`id` from the existing public `?type=<category>` endpoint client-side (no new read endpoint
needed) and automatically logs `VIEW` once loaded — no button tap required, and it fires
exactly once per visit regardless of how someone arrived at the page.

Wired up on this page: **VIEW** (automatic), **CALL**, **DIRECTION** (only shown if the
listing has latitude+longitude), **WEBSITE**, **FACEBOOK**, **INSTAGRAM** (only shown if that
listing field is filled in), **SHARE** (native share sheet via `navigator.share`, falls back
to copy-link), and **PHOTO_VIEW** (tapping the hero photo opens it full-screen — today's
stand-in for "opens the gallery," since each listing only has one `photo_url`; the same call
fires unchanged the moment a real multi-photo gallery exists).

Still not wired up: **EVENT_CLICK** (no Events feature exists anywhere in the app — Phase 2
item #16, not started — wiring this to something that doesn't exist would be worse than
leaving it as a hook) and **FAVORITE** (still correctly not implemented, per the original
instructions to only prepare the hook — `Analytics.gs`'s unused `logFavoriteHook_()` is ready
whenever it is built).

### Two new optional listing fields: `website_url`, `instagram_url`

Needed so the Website/Instagram buttons above have something to show. Add these as new
columns to all 5 directory sheets (Resorts, Restaurants, Cafes, SurfSchools, Activities) —
existing rows can leave them blank. Since `doGet`'s per-type block already loops over
`headers` dynamically (see the `id` patch above), any column present in the sheet flows
through to the public API automatically — no further doGet changes needed for these two.

Also added to the frontend: `register.html` (optional fields on the signup form),
`dashboard.html` (optional edit fields, plus **latitude**/**longitude** — those columns
already existed for map.html's pins but had no edit UI anywhere until now), and `admin.html`
(display labels for the pending-edits queue).

**⚠️ Please verify one thing before relying on these:** this project's Apps Script lives
outside these files (see "CRITICAL" note above), and there's no visibility here into whether
the real, currently-deployed `submit_edit`/`approve_edit`/`register`/`add_listing` handlers
write back a fixed, hardcoded list of field names, or write back whatever's in the submitted
object generically. The dashboard/register forms now send `website_url`, `instagram_url`,
`latitude`, and `longitude` — if the live script only recognizes the original 6 field names,
these new ones will be silently ignored on save (nothing will break, they just won't persist).
If that happens, the fix is adding those 4 names to whatever list Code.gs checks against — a
one-line change once the actual function is visible.

## Amenities + Google reviews display — added 2026-07-15

Every directory card, business.html, and the register/Dashboard forms now read/write **four**
new optional columns. None of these require any Code.gs change to *display* — `doGet`'s
per-type and `type=all` blocks already loop over whatever headers exist in a sheet tab and
pass them straight through (see the `id` patch above), so adding the column to a directory
sheet tab is enough for it to show up on the site immediately:

| Column | Type | Example | Shown as |
|---|---|---|---|
| `amenities` | comma-separated text | `Free Wifi, Pool, Air Conditioning, Beach Access` | icon chips (3 on cards, full list on business.html) |
| `google_rating` | number, 0–5 | `4.6` | star row + numeric rating |
| `google_reviews_count` | integer | `128` | "(128)" on cards, "128 Google reviews" on business.html |
| `google_maps_url` | URL | the listing's Google Maps link | "See on Google" link, business.html only |

Add these as columns to all 5 directory sheets (Resorts, Restaurants, Cafes, SurfSchools,
Activities) — existing rows can leave them blank, and any row missing `google_rating`
specifically just shows no rating (not a broken "0.0"). `amenities` works the same way — blank
means no chips render.

**`google_rating`/`google_reviews_count`/`google_maps_url` are meant to be kept honest with
the business's actual Google Maps listing** — there's no owner-facing input for them on
purpose (Dashboard/register.html only expose `amenities`). Update these three by editing the
sheet directly (admin, periodically, copying the real numbers from Google Maps) rather than
letting owners self-report a rating.

**`amenities` IS owner-editable** — register.html's form and dashboard.html's add-listing and
edit-listing forms all send an `amenities` field now, and the reference script above has
already been updated to persist it:
- `register`'s handler now appends `data.amenities` as a **new last column** to its
  `sheet.appendRow([...])` call for the Businesses tab.
- `update_listing`'s `updatable` array now includes `'amenities'`.
- `approve` needed no change — it already copies by header name dynamically, so `amenities`
  flows through automatically once both tabs have a matching column.

**What's left is just spreadsheet setup, not code:**
1. Paste the updated script (above, or the standalone `Code.gs` file) into Apps Script and
   redeploy as a new version of the existing deployment (same URL).
2. Add an `amenities` column as the **last (rightmost) column** on the Businesses sheet tab —
   `register`'s appendRow is positional, so it must land in that exact spot.
3. Add `amenities`, `google_rating`, `google_reviews_count`, and `google_maps_url` columns to
   all 5 directory tabs (Resorts, Restaurants, Cafes, SurfSchools, Activities) — order doesn't
   matter here since `doGet`/`approve`/`update_listing` all match by header name.
4. Fill in `google_rating`/`google_reviews_count`/`google_maps_url` yourself from each
   business's real Google Maps listing — these three are intentionally admin/sheet-only, not
   filled in through any form.


