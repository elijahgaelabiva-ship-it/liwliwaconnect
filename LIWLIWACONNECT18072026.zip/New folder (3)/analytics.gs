/**
 * ============================================================
 * Analytics.gs — Business Analytics System
 * ============================================================
 * Tracks how guests interact with business listings (views, calls,
 * directions, website/social clicks, shares, gallery/event opens).
 * Analytics only — this is NOT a booking system, and a failure here must
 * NEVER block the action it's attached to (see logAnalytics() below).
 *
 * SHEET: "Analytics" — auto-created on first use if it doesn't exist yet,
 * so there's no manual spreadsheet setup required beyond pasting this file.
 * Columns: Timestamp | BusinessID | EventType | GuestID | Device | Notes
 *
 * HOW THIS FILE CONNECTS TO YOUR EXISTING Code.gs
 * All .gs files in one Apps Script project share a single global scope, but
 * the project can only have ONE doGet(e) and ONE doPost(e) in total — so
 * this file deliberately does NOT define either. It only defines the
 * functions below (all uniquely named, won't collide with Code.gs).
 * Two small additions are needed in your existing doGet/doPost to route
 * analytics requests here. See "Analytics" section of docs/API.md for the
 * exact lines to add, and for the (also small) change needed so public
 * listings include a stable BusinessID.
 *
 * This file assumes Code.gs already defines: jsonOut(), SHEET_MAP,
 * ADMIN_PASSWORD — all three already exist in the current script (see
 * API.md) and are reused here rather than duplicated.
 * ============================================================
 */

// Every event type currently supported. Adding a new one later is just
// adding a string to this list (or even skipping that — see logAnalytics)
// — the sheet needs no new columns, so old and new clients keep working
// side by side.
var ANALYTICS_EVENT_TYPES = [
  'VIEW', 'CALL', 'DIRECTION', 'WEBSITE', 'FACEBOOK', 'INSTAGRAM',
  'SHARE', 'FAVORITE', 'PHOTO_VIEW', 'EVENT_CLICK'
];

// Event types treated as an outbound "action" click for summary grouping
// (as opposed to a passive VIEW or a SHARE). Purely presentational — not a
// database constraint — so this can be edited freely as new event types
// are added.
var ANALYTICS_CLICK_EVENT_TYPES = [
  'CALL', 'DIRECTION', 'WEBSITE', 'FACEBOOK', 'INSTAGRAM', 'EVENT_CLICK'
];

var ANALYTICS_SHEET_NAME = 'Analytics';
var ANALYTICS_HEADERS = ['Timestamp', 'BusinessID', 'EventType', 'GuestID', 'Device', 'Notes'];
var ANALYTICS_CACHE_KEY = 'analytics_rows_v1';
var ANALYTICS_CACHE_SECONDS = 120; // short TTL — a couple minutes stale is fine, wrong is not

// ---------------------------------------------------------------
// Sheet access
// ---------------------------------------------------------------

// Gets the Analytics tab, creating it with headers the first time any event
// is ever logged. Keeps setup to "paste this file" — no manual tab/column
// creation required.
function getOrCreateAnalyticsSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(ANALYTICS_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(ANALYTICS_SHEET_NAME);
    sheet.appendRow(ANALYTICS_HEADERS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// ---------------------------------------------------------------
// Writing
// ---------------------------------------------------------------

/**
 * Logs one guest interaction. This is the ONLY function that should ever
 * write to the Analytics sheet, so there's one place to change the row
 * shape if it ever needs to.
 *
 * @param {string} businessId  e.g. "resorts_14" (category + sheet row — see API.md)
 * @param {string} eventType   VIEW / CALL / DIRECTION / ... (any non-empty string is
 *                              accepted and logged — see ANALYTICS_EVENT_TYPES above)
 * @param {string} guestId     anonymous or logged-in guest id; '' if not available
 * @param {string} device      'Desktop' | 'Tablet' | 'Mobile'. Detected in the browser
 *                              (js/main.js AppAnalytics.detectDevice()), NOT here — Apps
 *                              Script web apps never receive a User-Agent header, so
 *                              server-side device sniffing isn't possible.
 * @param {string} notes       optional free text, defaults to '-'
 * @return {boolean} true if the row was written, false if logging failed
 *
 * IMPORTANT — never throws. Every call site can call this with zero risk to
 * whatever it's attached to. A failed analytics write must never prevent a
 * phone call, map, website, or social link from opening (see "fail
 * silently" requirement) — this function guarantees that by catching
 * everything internally instead of letting the caller worry about it.
 */
function logAnalytics(businessId, eventType, guestId, device, notes) {
  try {
    if (!businessId || !eventType) return false; // nothing meaningful to log
    var sheet = getOrCreateAnalyticsSheet_();
    var validDevices = ['Desktop', 'Tablet', 'Mobile'];
    sheet.appendRow([
      new Date(),
      String(businessId),
      String(eventType).toUpperCase(),
      guestId ? String(guestId) : '',
      device && validDevices.indexOf(device) !== -1 ? device : 'Unknown',
      notes ? String(notes) : '-'
    ]);
    CacheService.getScriptCache().remove(ANALYTICS_CACHE_KEY); // next read picks up this row
    return true;
  } catch (err) {
    return false; // swallowed on purpose — analytics fails silently, always
  }
}

// ---------------------------------------------------------------
// Reading — shared helpers (single source of truth for aggregation logic,
// reused by both getBusinessAnalytics() and getAnalyticsSummary() so
// nothing is duplicated between them)
// ---------------------------------------------------------------

// Reads every Analytics row ONCE, from cache when possible. This is the
// only place that ever calls getValues() on the Analytics sheet — both
// public read functions below reuse it instead of each doing their own
// spreadsheet read (avoids the "repeatedly call Spreadsheet methods"
// mistake as the log grows).
function getAnalyticsRows_() {
  var cache = CacheService.getScriptCache();
  var cached = cache.get(ANALYTICS_CACHE_KEY);
  if (cached) {
    try { return JSON.parse(cached); } catch (e) { /* fall through and re-read */ }
  }

  var sheet = getOrCreateAnalyticsSheet_();
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  var values = sheet.getRange(2, 1, lastRow - 1, ANALYTICS_HEADERS.length).getValues();
  var rows = values
    .filter(function (r) { return r[1]; }) // has a BusinessID
    .map(function (r) {
      return {
        timestamp: new Date(r[0]).getTime(),
        businessId: String(r[1]),
        eventType: String(r[2]),
        guestId: r[3] ? String(r[3]) : '',
        device: r[4] ? String(r[4]) : 'Unknown',
        notes: r[5] ? String(r[5]) : '-'
      };
    });

  // CacheService rejects values over ~100KB. Once the log outgrows that,
  // just skip caching instead of erroring — reads fall back to the sheet
  // every time, which still works, just without the cache speed-up.
  var serialized = JSON.stringify(rows);
  if (serialized.length < 90000) {
    cache.put(ANALYTICS_CACHE_KEY, serialized, ANALYTICS_CACHE_SECONDS);
  }
  return rows;
}

// Cutoff timestamp (ms since epoch) for a range keyword. null = no cutoff (all time).
function getRangeCutoff_(range) {
  var now = new Date();
  if (range === 'today') {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  }
  if (range === '7d') return now.getTime() - 7 * 24 * 60 * 60 * 1000;
  if (range === '30d') return now.getTime() - 30 * 24 * 60 * 60 * 1000;
  return null; // 'all' or anything unrecognized
}

// One-pass tally over an already-selected set of rows: counts per event
// type, a total, and a day-bucketed VIEW series for the chart. Shared by
// both public read functions below so the counting logic exists exactly
// once.
function tallyEvents_(rows, range) {
  var cutoff = getRangeCutoff_(range);
  var counts = {};
  var dailySeries = {}; // 'YYYY-MM-DD' -> VIEW count, for the "views by day" chart
  var total = 0;
  var tz = Session.getScriptTimeZone();

  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    if (cutoff !== null && row.timestamp < cutoff) continue;

    counts[row.eventType] = (counts[row.eventType] || 0) + 1;
    total++;

    if (row.eventType === 'VIEW') {
      var dayKey = Utilities.formatDate(new Date(row.timestamp), tz, 'yyyy-MM-dd');
      dailySeries[dayKey] = (dailySeries[dayKey] || 0) + 1;
    }
  }

  return { counts: counts, total: total, dailySeries: dailySeries };
}

// Batch-resolves business names for a list of "category_row" ids, grouped
// by category so each category's sheet is read at most once — regardless
// of how many ids need resolving. Used only for admin leaderboard display.
function resolveBusinessNames_(businessIds) {
  var byCategory = {};
  businessIds.forEach(function (id) {
    var parts = String(id).split('_');
    var category = parts[0];
    var row = Number(parts[1]);
    if (!SHEET_MAP[category] || !row) return;
    if (!byCategory[category]) byCategory[category] = [];
    byCategory[category].push({ id: id, row: row });
  });

  var names = {};
  Object.keys(byCategory).forEach(function (category) {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MAP[category]);
    if (!sheet) return;
    var data = sheet.getDataRange().getValues();
    var headers = data[0].map(normalizeHeader);
    var nameCol = headers.indexOf('name');
    if (nameCol === -1) return;
    byCategory[category].forEach(function (entry) {
      var rowValues = data[entry.row - 1]; // sheet row N === data[N-1] (data[0] is the header row)
      names[entry.id] = rowValues && rowValues[nameCol] ? String(rowValues[nameCol]) : entry.id;
    });
  });
  return names;
}

// ---------------------------------------------------------------
// Public read functions
// ---------------------------------------------------------------

/**
 * Analytics for ONE business.
 * @param {string} businessId
 * @param {string} range 'today' | '7d' | '30d' | 'all'
 * @return {Object} { businessId, range, counts, total, dailySeries }
 */
function getBusinessAnalytics(businessId, range) {
  var rows = getAnalyticsRows_().filter(function (r) { return r.businessId === businessId; });
  var tally = tallyEvents_(rows, range);
  return {
    businessId: businessId,
    range: range,
    counts: tally.counts,
    total: tally.total,
    dailySeries: tally.dailySeries
  };
}

/**
 * Sitewide analytics for the admin panel: totals per event type across
 * every business, plus leaderboards (top viewed / most clicked / most
 * shared, each with the resolved business name).
 * @param {string} range 'today' | '7d' | '30d' | 'all'
 * @return {Object} { range, counts, total, dailySeries, topViewed, mostClicked, mostShared }
 */
function getAnalyticsSummary(range) {
  var rows = getAnalyticsRows_();
  var cutoff = getRangeCutoff_(range);
  var filtered = cutoff === null ? rows : rows.filter(function (r) { return r.timestamp >= cutoff; });

  var tally = tallyEvents_(filtered, 'all'); // rows are already range-filtered above
  var perBusiness = {}; // businessId -> { view, click, share }

  for (var i = 0; i < filtered.length; i++) {
    var row = filtered[i];
    if (!perBusiness[row.businessId]) perBusiness[row.businessId] = { view: 0, click: 0, share: 0 };
    if (row.eventType === 'VIEW') perBusiness[row.businessId].view++;
    else if (row.eventType === 'SHARE') perBusiness[row.businessId].share++;
    else if (ANALYTICS_CLICK_EVENT_TYPES.indexOf(row.eventType) !== -1) perBusiness[row.businessId].click++;
  }

  function topN_(key, n) {
    return Object.keys(perBusiness)
      .map(function (id) { return { businessId: id, count: perBusiness[id][key] }; })
      .filter(function (b) { return b.count > 0; })
      .sort(function (a, b) { return b.count - a.count; })
      .slice(0, n);
  }

  var topViewed = topN_('view', 5);
  var mostClicked = topN_('click', 5);
  var mostShared = topN_('share', 5);

  // Resolve display names in one batched pass across all three leaderboards.
  var allIds = topViewed.concat(mostClicked, mostShared).map(function (b) { return b.businessId; });
  var names = resolveBusinessNames_(allIds);
  [topViewed, mostClicked, mostShared].forEach(function (list) {
    list.forEach(function (b) { b.name = names[b.businessId] || b.businessId; });
  });

  return {
    range: range,
    counts: tally.counts,
    total: tally.total,
    dailySeries: tally.dailySeries,
    topViewed: topViewed,
    mostClicked: mostClicked,
    mostShared: mostShared
  };
}

// ---------------------------------------------------------------
// Request routing — called from Code.gs's EXISTING doGet/doPost.
// See "Analytics" section of docs/API.md for the exact lines to add.
// ---------------------------------------------------------------

// GET ?type=business_analytics&id=...&range=...&email=...&password=...
// GET ?type=analytics_summary&range=...&password=ADMIN_PASSWORD
// Returns null (not jsonOut(null)) for any non-analytics request, so
// Code.gs's doGet knows to keep handling the request as normal.
function handleAnalyticsGet_(e) {
  var range = e.parameter.range || 'all';

  if (e.parameter.type === 'analytics_summary') {
    if (e.parameter.password !== ADMIN_PASSWORD) return jsonOut({ error: 'unauthorized' });
    return jsonOut(getAnalyticsSummary(range));
  }

  if (e.parameter.type === 'business_analytics') {
    var businessId = e.parameter.id;
    if (!businessId) return jsonOut({ error: 'missing id' });
    if (!verifyBusinessOwner_(businessId, e.parameter.email, e.parameter.password)) {
      return jsonOut({ error: 'unauthorized' });
    }
    return jsonOut(getBusinessAnalytics(businessId, range));
  }

  return null;
}

// POST {action: 'log_analytics', businessId, eventType, guestId, device, notes}
// Returns null for any non-analytics action, same convention as above.
function handleAnalyticsPost_(data) {
  if (data.action !== 'log_analytics') return null;

  // Always respond success regardless of whether the write actually landed
  // — the frontend (js/main.js AppAnalytics.track) is fire-and-forget and
  // never reacts to this response either way. See logAnalytics() docblock.
  logAnalytics(data.businessId, data.eventType, data.guestId, data.device, data.notes);
  return jsonOut({ success: true });
}

// Confirms email+password match the given business's owner_email/
// owner_password — the same rule Code.gs's update_listing already
// enforces. Reimplemented here (rather than calling into Code.gs) because
// businessId ("category_row") needs to be split apart to find the right
// sheet/row, whereas Code.gs's version takes category and row as separate
// parameters already — small, deliberate, unavoidable duplication.
function verifyBusinessOwner_(businessId, email, password) {
  var parts = String(businessId).split('_');
  var category = parts[0];
  var row = Number(parts[1]);
  var sheetName = SHEET_MAP[category];
  if (!sheetName || !row) return false;

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) return false;

  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(normalizeHeader);
  var emailCol = headers.indexOf('owner_email') + 1;
  var passCol = headers.indexOf('owner_password') + 1;
  if (emailCol === 0 || passCol === 0) return false;

  var actualEmail = sheet.getRange(row, emailCol).getValue();
  var actualPass = sheet.getRange(row, passCol).getValue();
  return String(actualEmail) === String(email) && String(actualPass) === String(password);
}

// ---------------------------------------------------------------
// Favorites hook — NOT a Favorites feature. Favorites don't exist yet
// anywhere in this project. This exists only so that whenever Favorites is
// built, the analytics wiring for it already exists and needs no schema or
// backend change — just a call to logAnalytics(businessId, 'FAVORITE', ...)
// from wherever the Favorites button ends up living.
// ---------------------------------------------------------------
function logFavoriteHook_(businessId, guestId, device) {
  return logAnalytics(businessId, 'FAVORITE', guestId, device, '-');
}
